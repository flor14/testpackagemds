# testpackagemds 0.1.0
A package created to try a GitHub Actions workflow!

## Installation

```bash
$ pip install testpackagemds
```

## Usage



## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.




